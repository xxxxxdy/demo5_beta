<template>
    <div style="background:white; border-radius: 5px; margin-bottom: 5px;"
        @mouseenter="rollingForDetail" @mouseleave="rollingCancel">
        &nbsp &nbsp <b>attribute</b> &nbsp
        <select style="padding-left:3px" :class="'seletor'+index" @change="changeDataValue">
            <option v-for="item in data_value_name">{{item}}</option>  
        </select>
        <br>
        <div :style="style_shape" @mouseenter="showAdvanceWindows"></div>
        <div :style="style_color">&nbsp &nbsp persistent &nbsp {{per_val}}</div>
        
        <div class="range" style="position: relative; padding-left: 18px; padding-bottom: 30px;" >
                <input type="range" class="persistent" min="0" :max="coarse_max"
                  :step="coarse_step" v-model="per_val" @input="changePersistent">
  
        </div>
        <input type="button" class="kill" value="X" @click="$emit('delete', index)">
        
        <input type="button" class="reset" value="reset" @click="resetOperation"  :style="style_reset">
        <input type="button" class="filter" value="filter" @click="showSubFilter">
        <input type="button" class="align" value="primary" @click="alignAsBase">
        <input type="button" class="reorder" value="reorder" @click="reorderVisualCode">
        
    </div>

    <div class="sub-filter" v-show="filter_hover" style="cursor:pointer">
        <li id="vc">visual code</li>
        <li id="ta">time axis</li>
        <li id="cc">code cell</li>
    </div>

    <div class="visual-code-canvas" :id="'canvas'+index" @scroll="recordScroll" >
        <div style="display:inline-block">
            <div :class="'code-list'+index" v-for="item in codes_message" v-show="item.sim_show">
                <div :style="'height:'+onecode_height+'px'">
                <VisualCode ref="subcode" :target="index" :mapping="item.idx" :draw_message="item.value" 
                    :line_opacity="line_opacity" :rect_opacity="rect_opacity" :show="item.show"
                    :code_name="item.name" :show_name="show_name" :filter="item.filter"
                    @highlight="addInteractive" @delete="removeInteractive"/></div>
            </div>
            <div :id="'box'+index" :style="style_box"></div>
        </div>
        <div class="my-scroll-bar" :style="{top:mySrollBarTop}">
            <div class="my-scroll-bar-item" v-for="item in codes_message" :key="item" :style="{backgroundColor:getColorByMsg(item), height:myScorllBarItemHeight}"></div>
        </div>
    </div> 
</template>

<style scoped>
.my-scroll-bar{
    display: inline-block;
    position: absolute;
    right: 0%;
    height: 100%;
}

.my-scroll-bar-item{
    width: 10px;
}

.visual-code-canvas{
    position: relative;
    width: 100%;
    height: 84%;
    border-radius: 5px;
    overflow-y: auto;
    background: white;
}
.kill{
    position: absolute;
    right: 5px;
    top: 5px;
    color: red;
}
input[type=range]{
    position: absolute;
    left: 12%;
    right: 8%
}

.align, .filter, .reset,.reorder{
    margin-left: 12px;
    margin-bottom: 2px;
}

.sub-filter{
    position: absolute;
    padding: 2px;
    border: 1px black solid;
    top: 80px;
    left: 110px;
    background-color: white;
    z-index: 100;
}

li{
    list-style: none;
}

li:hover{
    font-weight: bold;
}

</style>

<script>
import { data_lists, visualcode_object, interactive_list, calculateInitPersistent, pers_list} from '../util/codeList';
import { color_for_highlight, PERS_COLOR, pers_index } from '../util/colorMapping';
import { re_sort_order, sort_order, updateOrder, getReSortOrder } from '../util/sortForVisual';
import { CODE_PADDING, CODE_WIDTH, user_parameters } from '../util/parameters';
import { getMarksForDraw, CodeToString } from '../util/drawDataManager'
import VisualCode from './VisualCode.vue';
import bus from "../util/eventBus";
import { data_value_line, data_type_name, data_field, data_value } from '../util/dataManager';
import { getSimilarity, data_dis } from "../util/similarityCalculate"
import MySwitch from './MySwitch.vue';

export default{
    props:{
        index:{type:[String, Number], default: 0},
        show_name:{type:[Boolean], default:false}
    },
    components: { VisualCode, MySwitch },
    emits:['delete'],
    data() {
        return {
            mySrollBarTop:'0px',
            data_value_name:[],
            codes_message:[],
            codes_message_beta: [],
            is_beta: false,
            line_opacity: user_parameters["line_opacity"],
            rect_opacity: user_parameters["rect_opacity"],
            /// these two parameters should be change if the canvas change
            onecode_height: 60, 
            once_render_num: 15,
            first_on_screen: 0,
            coarse_max: 1.2,
            coarse_step:0.05,
            // coarse_per: 0,
            // fine_max: 0.1,
            fine_step:0.005,
            // fine_per: 0,
            per_val: 0,
            base_sort: false,
            sort_index: -1,
            style_color:{color: "red", display:"inline-block"},
            style_shape:{display:"inline-block", width:"12px", height:"12px","margin-left": "12px"},
            style_reset:{color: "grey"},
            filter_hover: false,
            sort_msg: null,
            style_box: {background: "aqua", position:"absolute", zIndex: 100, 
                left: "0px", top: "0px", width: "0px", height: "0px", opacity: 0.5},
            /// le: x axis of box relative to main
            /// rex: ... of div.visual-code-canvas ...
            /// canx: ... of canvas._0_0 ...
            box_para:{le: 0, tp: 0, ri: 0, bt: 0, rex: 0, rey: 0, rewi: 0, canx:0, canid: -1}
        };
    },
    computed:{
        myScorllBarItemHeight(){
            return (100 / this.codes_message.length) + '' + '%'
        }
    },
    methods: {
        getColorByMsg(code_msg){
            //if 密：return red
            //else if 疏 return ...
            // else if 太疏 return white
            return 'red'
        },
        closeSubFilter(e){
            this.filter_hover = false;
            document.removeEventListener("mouseup", this.closeSubFilter);
            e = e || window.event;
            let tar = e.target;
    
            if(tar.tagName !== "LI") return;
            let str = tar.id;
            if(str === "vc") this.filterVisCode();
            else if(str === "ta") this.filterTimeRange(); 
            else if(str === "cc") this.filterCodeCell();

            else return;
        },

        showSubFilter(){
            this.filter_hover = true;
            let closeFunction = this.closeSubFilter;
            // let filterFunction = this.filterVisCode;
            // function removeCloseFunction(e){
            //     document.removeEventListener("mousedown", closeFunction);
            //     document.removeEventListener("mouseup", removeCloseFunction);

            //     e = e || window.event;
            //     let tar = e.target;
            //     console.log(tar);
            //     if(tar.tagName !== "LI") return;
            //     let str = tar.id;
            //     if(str == "vc") filterFunction();
            //     else return;
            // }

            document.addEventListener("mouseup", closeFunction);
            // document.addEventListener("mouseup", removeCloseFunction);
        },

        // changeScaleForShow(up){
        //     if(up) this.scale_num++;
        //     else if(this.scale_num>1) this.scale_num--;
        //     for(let i=0; i<this.codes_message.length; i++){
        //         if(i%this.scale_num) this.codes_message[i].sim_show = false;
        //         else this.codes_message[i].sim_show = true;
        //     }
        //     this.updateScrollForDraw(this.scroll_unit.scrollTop)
        // },

        // scaleSize(e){
        //     e = e || window.e;
        //     let ys = e.pageY;
        //     let change = this.changeScaleForShow;
        //     function changeSize(e){
        //         e = e || window.e;
        //         change(e.pageY > ys)
        //         ys = e.pageY;
        //     }

        //     function afterChangeSize(){
        //         document.removeEventListener("mousemove", changeSize);
        //         document.removeEventListener("mouseup", afterChangeSize);
        //     }

        //     document.addEventListener("mousemove", changeSize);
        //     document.addEventListener("mouseup", afterChangeSize);
        // },
        
        reorderVisualCode(){
            updateOrder(this.index, this.data_type, this.sort_msg);
            let tmp = this.sort_index;
            this.codes_message.sort(function(a, b){
                return re_sort_order[tmp][a.idx] - re_sort_order[tmp][b.idx]
            })
            for(let i =this.first_on_screen, j=0; i<this.codes_message.length && j<this.once_render_num; i++, j++){
                this.codes_message[i].show = true;
            }

            if(this.base_sort === true) 
                bus.emit("alignOrder", [this.sort_index, this.scroll_unit.scrollTop])
        },

        alignAsBase(){
            this.base_sort = true;
            bus.emit("alignOrder", [this.index, this.scroll_unit.scrollTop])
        },

        resetOperation(){
            if(this.style_reset["color"] === "grey") return;
            if(this.is_beta) {
                for(let i=0, j=this.codes_message.length; i<j; i++)
                    this.codes_message[i] = JSON.parse(JSON.stringify(this.codes_message_beta[i]));
            }
            for(let i=0, j=this.codes_message.length; i<j; i++){
                this.codes_message[i]["sim_show"] = true;
 
                this.$refs.subcode[i].resetFilter();
            }

            this.sort_index = this.index;
            let tmp = this.sort_index;
            this.codes_message.sort(function(a, b){
                return re_sort_order[tmp][a.idx] - re_sort_order[tmp][b.idx]
            })
            
            this.style_reset["color"] = "grey";
        },

        filterVisCode(){
            let idx = this.index, sort_idx = this.sort_index;
            document.styleSheets[0].insertRule(".code-list"+this.index+":hover{border: 2px black solid;}", 0);
            
            var start_idx = -1, upper = -1, lower = -1;
            var codes = document.querySelectorAll(".code-list"+this.index);

            function moveForSelect(e){
                e = e || window.event;
                let tar = e.target;
                if(tar.tagName !== "CANVAS") return;
                let str = tar.id;
                let select_code = Number(str.split('_')[2]);

                if(start_idx === -1) {
                    start_idx = re_sort_order[sort_idx][select_code]; 
                    upper = start_idx;
                    lower = start_idx;
                    codes[start_idx].setAttribute("style", "border: 2px black solid");
                    return;
                }
                
                let nows = re_sort_order[sort_idx][select_code];
                if(nows > upper) {
                    for(let i=upper+1; i<=nows; i++) codes[i].setAttribute("style", "border: 2px black solid");
                    upper = nows;
                } 
                else if(nows < lower) {
                    for(let i=nows; i<lower; i++) codes[i].setAttribute("style", "border: 2px black solid");
                    lower = nows;
                }
                else if(nows < start_idx){
                    for(let i=lower; i<nows; i++) codes[i].setAttribute("style", "border: not specified");
                    lower = nows;
                }
                else if(nows > start_idx){
                    for(let i=nows+1; i<=upper; i++) codes[i].setAttribute("style", "border: not specified");
                    upper = nows;
                }
                else{
                    for(let i=lower; i<=upper; i++) codes[i].setAttribute("style", "border: not specified");
                    upper = start_idx;
                    lower = start_idx;
                    codes[start_idx].setAttribute("style", "border: 2px black solid");
                }
            }

            function selectVisCode(){
                document.getElementById("canvas"+idx).onmousemove = moveForSelect;
            }

            function afterRuleClick(){
                if(lower>=0 && upper>=0){
                    for(let i=lower; i<=upper; i++) codes[i].setAttribute("style", "border: not specified");
                }

                document.styleSheets[0].deleteRule(0);
                document.getElementById("canvas"+idx).onmousemove = null;
                document.removeEventListener("mousedown", selectVisCode);
                document.removeEventListener("mouseup", afterRuleClick);
                
                if(lower>=0 && upper>=0)  bus.emit("filterCode", [sort_idx, lower, upper]);
            }

            document.addEventListener("mousedown", selectVisCode)
            document.addEventListener("mouseup", afterRuleClick)
        },

        realCutFunction(){
            this.style_box["left"]= "0px";
            this.style_box["top"]= "0px";
            this.style_box["width"]= "0px";
            this.style_box["height"]= "0px";

            let new_x = this.box_para["le"]-this.box_para["canx"];
            let new_x2 = this.box_para["ri"]-this.box_para["canx"];
            if(new_x>new_x2){let tmp=new_x; new_x=new_x2; new_x2=tmp;}
            if(new_x<0) new_x=0;
            if(new_x2>CODE_WIDTH/2) new_x2=CODE_WIDTH/2;
            if(new_x === 0 && new_x2===CODE_WIDTH/2) return;
            new_x *=2, new_x2*=2;
            if(!this.is_beta) {
                this.codes_message_beta.splice(0, this.codes_message_beta.length);
                for(let i=0, j=this.codes_message.length; i<j; i++)
                    this.codes_message_beta.push(JSON.parse(JSON.stringify(this.codes_message[i]))); 
                this.is_beta = true;
            }

            // console.log(new_x, new_x2);
            let k = CODE_WIDTH / (new_x2-new_x);
            let b = -k * new_x;
            // console.log(this.codes_message[0])
            for(let i=0, j=this.codes_message.length; i<j; i++){
                let m = this.codes_message[i].value.hline.length;        
                for(let h=0; h<m; h++){
                    if(this.codes_message[i].value.hline.x2 < 0) continue;
                    if(this.codes_message[i].value.hline.x < CODE_WIDTH) continue;
                    this.codes_message[i].value.hline[h].x = k*this.codes_message[i].value.hline[h].x + b;
                    this.codes_message[i].value.hline[h].x2 = k*this.codes_message[i].value.hline[h].x2 + b;
                    this.codes_message[i].value.rect[h].x = k*this.codes_message[i].value.rect[h].x + b;
                    this.codes_message[i].value.rect[h].width = k*this.codes_message[i].value.rect[h].width;
                    this.codes_message[i].value.vline[h].x = k*this.codes_message[i].value.vline[h].x + b;
                }
            }
            
            for(let i=0, j=this.codes_message.length; i<j; i++){
                this.$refs.subcode[i].drawImage();
            }
            this.style_reset["color"] = "black";
  
        },

        cutTimeRange(){
            let downFunction = this.changeBoxLeftTop;
            let moveFunction = this.moveBox;
            let upFunction = this.cutTimeRange;
            document.removeEventListener("mousedown", downFunction);
            document.removeEventListener("mousemove", moveFunction);
            document.removeEventListener("mouseup", upFunction);

            this.realCutFunction();
        },

        moveBox(e){
            let x = e.offsetX, y = e.offsetY;
            let tar = e.target;
            if(tar.nodeName === "BODY") return;
            if(tar.nodeName === "CANVAS"){
                let str = tar.id;
                this.box_para["canid"] = Number(str.split('_')[2]);
            }
            while(tar.nodeName !== "MAIN"){
                x += tar.offsetLeft, y += tar.offsetTop;
                tar =  tar.offsetParent;
            }
            this.box_para["ri"] = x;
            this.box_para["bt"] = y;

            if(x-this.box_para["rex"]>this.box_para["rewi"]) this.style_box["width"] = String(this.box_para["rewi"]-this.box_para["le"])+"px";
            else{
                let wid = x-this.box_para["le"];
                if(wid > 0){
                    this.style_box["width"] = String(wid)+"px";
                }
                else{
                    this.style_box["left"] = String(x-this.box_para["rex"])+"px";
                    this.style_box["width"] = String(-wid)+"px";
                }
            } 
            
            let heig = y-this.box_para["tp"];
            if(heig>0){
                this.style_box["height"] = String(heig)+"px";
            }
            else{
                this.style_box["top"] = String(y-this.box_para["rey"])+"px";
                this.style_box["height"] = String(-heig)+"px";
            }
        },
        changeBoxLeftTop(e){                                        
            let x = e.offsetX, y = e.offsetY;
            let tar = e.target;
            if(tar.nodeName === "BODY") return;
            while(tar.nodeName !== "MAIN"){
                x += tar.offsetLeft, y += tar.offsetTop;
                tar =  tar.offsetParent;
            }
            this.box_para["le"] = x;
            this.box_para["tp"] = y;
            this.style_box["left"] = String(x-this.box_para["rex"])+"px";
            this.style_box["top"] = String(y-this.box_para["rey"])+"px";
            this.style_box["width"] = "0px";
            this.style_box["height"] = "0px";
            let moveFunction = this.moveBox;
            let upFunction = this.cutTimeRange;
            document.addEventListener("mousemove", moveFunction);
            document.addEventListener("mouseup", upFunction);
        }, 
        filterTimeRange(){
            let downFunction = this.changeBoxLeftTop;
            document.addEventListener("mousedown", downFunction);
        },

        realGetCodeRange(){
            this.style_box["left"]= "0px";
            this.style_box["top"]= "0px";
            this.style_box["width"]= "0px";
            this.style_box["height"]= "0px";

            let new_x = this.box_para["le"]-this.box_para["canx"];
            let new_x2 = this.box_para["ri"]-this.box_para["canx"];
            if(new_x>new_x2){let tmp=new_x; new_x=new_x2; new_x2=tmp;}
            if(new_x<0) new_x=0;
            if(new_x2>CODE_WIDTH/2) new_x2=CODE_WIDTH/2;
            if(new_x === 0 && new_x2===CODE_WIDTH/2) return;
            // new_x *=2, new_x2*=2;
            /* According to parameter in CodeToString function, */
            /* the string of a character in string is 480/24 = 20 */
            
            new_x = Math.ceil(new_x/10); // new_x*2/20
            new_x2 = Math.ceil(new_x2/10);
            if(new_x2 === new_x) new_x2++;
            let sstr = this.codes_message[re_sort_order[this.sort_index][this.box_para.canid]]['str'].substring(new_x, new_x2);
            let slen = sstr.length * 20;
            let strue = [], sfalse = [];
            for(let i=0; i<this.codes_message.length; i++){
                this.codes_message[i].filter.splice(0, this.codes_message[i].filter.length);
                let iidx = -1;
                let flag = false;
                while(true){
                    iidx = this.codes_message[i]['str'].indexOf(sstr, iidx+1);
                    if(iidx === -1) break;
                    flag = true;
                    /// draw function
                    this.codes_message[i].filter.push([iidx*20, slen]);
                    // console.log(iidx, i, sstr)
                }
                if(flag) strue.push(this.$refs.subcode[i].getDataIdx())
                else sfalse.push(this.$refs.subcode[i].getDataIdx())

            }

            let sorder = strue.concat(sfalse);
            sort_order[this.index] = sorder;
            getReSortOrder(this.index);
            
            this.style_reset["color"] = "black";
            // console.log(re_sort_order[this.index], sort_order[this.index])
            // console.log(this.codes_message)
            let tmp = this.index;
            this.codes_message.sort(function(a, b){
                return re_sort_order[tmp][a.idx] - re_sort_order[tmp][b.idx]
            })
            for(let i =this.first_on_screen, j=0; i<this.codes_message.length && j<this.once_render_num; i++, j++){
                this.codes_message[i].show = true;
            }
            //    console.log(this.codes_message)
            if(this.base_sort === true) 
                bus.emit("alignOrder", [this.sort_index, this.scroll_unit.scrollTop])
        },

        getCodeRange(){
            let downFunction = this.changeBoxLeftTopForCell;
            let moveFunction = this.moveBox;
            let upFunction = this.getCodeRange;
            document.removeEventListener("mousedown", downFunction);
            document.removeEventListener("mousemove", moveFunction);
            document.removeEventListener("mouseup", upFunction);

            this.realGetCodeRange();
        },

        changeBoxLeftTopForCell(e){                                          
            let x = e.offsetX, y = e.offsetY;
            let tar = e.target;
            if(tar.nodeName === "BODY") return;
            if(tar.nodeName === "CANVAS"){
                let str = tar.id;
                this.box_para["canid"] = Number(str.split('_')[2]);
            }
            while(tar.nodeName !== "MAIN"){
                x += tar.offsetLeft, y += tar.offsetTop;
                tar =  tar.offsetParent;
            }
            this.box_para["le"] = x;
            this.box_para["tp"] = y;
            this.style_box["left"] = String(x-this.box_para["rex"])+"px";
            this.style_box["top"] = String(y-this.box_para["rey"])+"px";
            this.style_box["width"] = "0px";
            this.style_box["height"] = "0px";
            let moveFunction = this.moveBox;
            let upFunction = this.getCodeRange;
            document.addEventListener("mousemove", moveFunction);
            document.addEventListener("mouseup", upFunction);
        }, 

        filterCodeCell(){
            let downFunction = this.changeBoxLeftTopForCell;
            document.addEventListener("mousedown", downFunction);
        },

        /// This function is called while changing the filter
        updateDrawMessage(pers = 0, init = false){
            data_lists[this.index].splice(0, data_lists[this.index].length);
            for(let i=0, len=visualcode_object[this.data_type].length; i<len; i++){
                data_lists[this.index].push(visualcode_object[this.data_type][i].getDataForOneDraw(pers));
            }
            if(init) updateOrder(this.index, this.data_type);
        },

        /// This function is called while changing the mapping channel
        updateMappingChannel(){         
            this.codes_message.splice(0, this.codes_message.length);

            this.is_beta = false;
            this.codes_message_beta.splice(0, this.codes_message_beta.length);

            for(let i=0, len=data_lists[this.index].length; i<len; i++){
                let w1 = visualcode_object[this.data_type][sort_order[this.sort_index][i]].total_width;
                let w2 = visualcode_object[this.data_type][sort_order[this.sort_index][i]].start_width;
                let d_idx = sort_order[this.sort_index][i];
                let draw_value = { idx: d_idx, show: false, sim: 0, filter: [],
                    sim_show: true, name: visualcode_object[data_value_line[0]][d_idx].name};
                draw_value['value'] = getMarksForDraw(data_lists[this.index][sort_order[this.sort_index][i]], w1, w2);
                this.codes_message.push(draw_value);
            }
            for(let i=0; i<this.codes_message.length; i++)
                this.codes_message[i]["str"] = CodeToString(this.codes_message[i].value);
            for(let i=0, j=0, cnt=0; i<this.codes_message.length && j<this.once_render_num; i++){
                if(this.codes_message[i].sim_show === true){
                    cnt++;
                    if(cnt>this.first_on_screen){
                        this.codes_message[i].show = true;
                        j++;
                    }
                }
            }
            /// For update circle in linechart in real time 
            if(interactive_list.length>0){
                bus.emit("clickForLine", -1);
                
                let idx = interactive_list[interactive_list.length-1]
                bus.emit("analysisCode", [idx, this.index, this.codes_message[re_sort_order[this.sort_index][idx]]['value']]);
            }
        },

        /// This function is called just when initializing for synchronizing interaction
        synchronizeHighlight(){
            for(let i=0; i<interactive_list.length; i++){
                this.$refs.subcode[re_sort_order[this.sort_index][interactive_list[i]]].highlightReceiver();
            }
        },

        changeFinePersistent(event){
            event = event || window.event;
            if(event.wheelDelta){
                if(event.wheelDelta > 0)
                    this.per_val += this.fine_step;
                else
                    this.per_val -= this.fine_step;
            }
            else if(event.detail){
                if(event.wheelDelta > 0)
                    this.per_val += this.fine_step;
                else
                    this.per_val -= this.fine_step;
            }
            if(this.per_val < 0) this.per_val = 0;
            this.per_val = parseFloat(this.per_val.toFixed(12));
            this.changePersistent()
        },

        rollingForDetail(){
            window.onmousewheel = document.onmousewheel = this.changeFinePersistent;
            document.addEventListener("DOMMouseScroll", this.changeFinePersistent, false)
        },

        rollingCancel(){
            window.onmousewheel = document.onmousewheel = null;
            document.removeEventListener("DOMMouseScroll", this.changeFinePersistent, false)
        },
        
        /// change persistent
        changePersistent(){
            this.per_val = Number(this.per_val)
            pers_list[this.index][1] = this.per_val
            
            this.updateDrawMessage(this.per_val)
            this.updateMappingChannel()
        },

        /// change value attribute
        changeDataValue(){
            for(let i=2, len=data_type_name.length; i<len; i++){
                if(this.type_selector.value === data_type_name[i]){
                    this.data_type = i;
                    break;
                }
            }
            /// or init any other persistent value
            this.per_val = 0;
            this.coarse_max = data_field["max_domain"][this.data_type] - data_field["min_domain"][this.data_type]
            this.coarse_step = this.coarse_max / 50
            this.fine_max = data_field["step"][this.data_type]
            this.fine_step = this.fine_max / 50

            pers_list[this.index][0] = this.data_type;
            pers_list[this.index][1] = this.per_val;

            this.updateDrawMessage(this.per_val)
            this.updateMappingChannel()
        },

        /// Interactive data
        addInteractive(msg){
            interactive_list.push(msg);
            bus.emit("clickForLine", msg);
            bus.emit("analysisCode", [msg, this.index, this.codes_message[re_sort_order[this.sort_index][msg]]['value']]);
        },

        removeInteractive(msg){
            for(let i=0; i<interactive_list.length; i++){
                if(msg === interactive_list[i]){
                    interactive_list.splice(i, 1);
                    break;
                }
            }
            bus.emit("clickForLine", msg);
            if(interactive_list.length > 0){
                let idx = interactive_list[interactive_list.length-1]
                bus.emit("analysisCode", [idx, this.index, this.codes_message[re_sort_order[this.sort_index][idx]]['value']]);
            }  
            else
                bus.emit("analysisCode", [-1, -1, {}]);
        },

        /// This function is used to record which codes should be render
        recordScroll(e){
            console.log(e);
            this.mySrollBarTop = e.srcElement.scrollTop + 'px'
            let scroll_y = this.scroll_unit.scrollTop;
            if(this.sort_index !== this.index || this.base_sort === true)
                bus.emit("synchronizeScroll", [this.index, scroll_y])
            this.updateScrollForDraw(scroll_y)
        },

        updateScrollForDraw(scroll_y = 0){
            /// This 2 is because the marign 2px in sub div
            this.first_on_screen = Math.floor(scroll_y / (this.onecode_height+2))
            let max_top = this.codes_message.length-this.once_render_num
            if( max_top > 0 && this.first_on_screen > max_top ) 
                this.first_on_screen = max_top;
            for(let i=0, j=0, cnt=0; i<this.codes_message.length && j<this.once_render_num; i++){
                if(this.codes_message[i].sim_show === true){
                    cnt++;
                    if(cnt>this.first_on_screen){
                        this.codes_message[i].show = true;
                        j++;
                    }
                }
            }
        },

        /// This function is used to clear highlight and called in CodeCenter
        clearHighlight(){           
            for(let key in color_for_highlight){
                this.$refs.subcode[re_sort_order[this.sort_index][key]].highlightReceiver();
            }
        }
    },

    watch:{
        show_name(new_value, old_value){
            /// This number is the value of font size
            if(new_value){
                this.onecode_height += 25;
            } 
            else{
                this.onecode_height -= 25;
            }
            this.updateScrollForDraw(this.scroll_unit.scrollTop);
        }
    },

    created() {
        bus.on("updateDataset", msg=>{
            this.data_value_name.splice(0, this.data_value_name.length)
            for(let i=0; i<data_value_line.length; i++)
                this.data_value_name.push(data_type_name[data_value_line[i]])
            this.data_type = data_value_line[0]
            this.coarse_max = data_field["max_domain"][this.data_type] - data_field["min_domain"][this.data_type]
            this.coarse_step = this.coarse_max / 50
            // this.fine_max = data_field["step"][this.data_type]
            // this.fine_step = this.fine_max / 50
            this.fine_step = data_field["step"][this.data_type] / 50

            pers_list[this.index][0] = this.data_type;
            pers_list[this.index][1] = this.per_val;
        })
        bus.on("updateVisualCode", msg=>{
            this.updateDrawMessage(this.per_val, msg);
            this.updateMappingChannel();
        })
        bus.on("updateDataOrder", msg=>{
            this.sort_msg = msg;
            if(this.sort_index !== this.index) return;

            updateOrder(this.index, this.data_type, msg);
            let tmp = this.sort_index;
            this.codes_message.sort(function(a, b){
                return re_sort_order[tmp][a.idx] - re_sort_order[tmp][b.idx]
            })
            for(let i =this.first_on_screen, j=0; i<this.codes_message.length && j<this.once_render_num; i++, j++){
                this.codes_message[i].show = true;
            }

            if(this.base_sort === true) 
                bus.emit("alignOrder", [this.sort_index, this.scroll_unit.scrollTop])
        })
        bus.on("changeRectOpacity", msg=>{  
            this.rect_opacity = msg
        })
        bus.on("changeLineOpacity", msg=>{  
            this.line_opacity = msg
        })

        /// including some code of calculating similarity, may modify later
        bus.on("clickForLine", msg=>{
            if(msg === -1) return
            let idx = re_sort_order[this.sort_index][msg]

            for(let i=0; i<this.codes_message.length; i++){
                this.codes_message[i]['sim']=getSimilarity(
                    this.codes_message[i]['str'], this.codes_message[idx]['str'])

                // if(i<12)  console.log(this.codes_message[i]['sim'])
            }
            // console.log("-------------------------------")
            this.$refs.subcode[re_sort_order[this.sort_index][msg]].highlightReceiver();
            
        })

        bus.on("showSimilarityCode", msg=>{
            if(msg === 0) { 
                for(let i=0; i<this.codes_message.length;i++){
                    this.codes_message[i].sim_show = true;
                }
                return;
            }

            for(let i=0; i<this.codes_message.length;i++){
                if(this.codes_message[i].sim < msg){
                    this.codes_message[i].sim_show = true;
                    this.codes_message[i].show = true;
                }
                    
                else this.codes_message[i].sim_show = false;
            }
            /// update some code which is not showed before
            this.updateScrollForDraw(this.scroll_unit.scrollTop);
        })

        bus.on("calculateDistance", msg=>{
            if(msg !== this.index) return;
            let len = this.codes_message.length;
            data_dis.splice(0, data_dis.length);
            let dis = new Array(len).fill(0).map(v => new Array(len).fill(0))
            for(let i=0; i<len; i++){
                for(let j=i+1; j<len; j++){
                    dis[i][j] = getSimilarity(this.codes_message[re_sort_order[this.sort_index][i]]['str'],
                      this.codes_message[re_sort_order[this.sort_index][j]]['str']);
                    dis[j][i] = dis[i][j];
                }
                data_dis.push(dis[i]);
            }
        })

        bus.on("alignOrder", msg=>{
            if(msg[0]===-1) this.sort_index = this.index;
            else this.sort_index = msg[0];
            if(this.sort_index!== this.index) this.base_sort=false;
            let tmp = this.sort_index;
            this.codes_message.sort(function(a, b){
                return re_sort_order[tmp][a.idx] - re_sort_order[tmp][b.idx]
            })
            this.scroll_unit.scrollTo(0, msg[1]);
            this.updateScrollForDraw(this.scroll_unit.scrollTop);
            this.style_reset["color"] = "black";
        })

        bus.on("synchronizeScroll", msg=>{
            if(msg[0] === this.index) return;
            if(this.sort_index === this.index && this.base_sort === false) return;
            this.scroll_unit.scrollTo(0, msg[1]);
            this.updateScrollForDraw(msg[1]);
        })

        bus.on("filterCode", msg=>{
            let idx = msg[0], lower = msg[1], upper = msg[2];

            if(idx === this.sort_index){
                for(let i=0; i<lower; i++) this.codes_message[i]["sim_show"] = false;
                for(let i=lower; i<=upper; i++) this.codes_message[i]["sim_show"] = true;
                for(let i=upper+1,j=this.codes_message.length; i<j;i++) this.codes_message[i]["sim_show"] = false;
            }
            else{
                for(let i=0; i<lower; i++) 
                    this.codes_message[re_sort_order[this.index][sort_order[idx][i]]]["sim_show"] = false;
                for(let i=lower; i<=upper; i++) 
                    this.codes_message[re_sort_order[this.index][sort_order[idx][i]]]["sim_show"] = true;
                for(let i=upper+1,j=this.codes_message.length; i<j;i++) 
                    this.codes_message[re_sort_order[this.index][sort_order[idx][i]]]["sim_show"] = false;
            }
            this.style_reset["color"] = "black";
            this.updateScrollForDraw();
        })

        /// get value type list, default the first one
        for(let i=0; i<data_value_line.length; i++)
            this.data_value_name.push(data_type_name[data_value_line[i]])
        this.data_type = data_value_line[0]
        /// update persistent range
        this.coarse_max = data_field["max_domain"][this.data_type] - data_field["min_domain"][this.data_type]
        this.coarse_step = this.coarse_max / 50
        // this.fine_max = data_field["step"][this.data_type]
        // this.fine_step = this.fine_max / 50
        this.fine_step = data_field["step"][this.data_type] / 50
        
        if(this.show_name)   this.onecode_height += 25;
        this.sort_index = this.index;

        for(let i=0; i<pers_index.length; i++){
            if(pers_index[i]===-1){
                pers_index[i] = this.index;
                this.style_color["color"] = PERS_COLOR[i];
                this.style_shape["background"] = PERS_COLOR[i];
                switch(i){
                    case 0: this.style_shape["border-radius"] = "6px";break;
                    case 2: this.style_shape["transform"] = "rotate(45deg)"; break;
                    default: break;
                }
                break;
            }
        }
        data_lists[this.index] = []
        pers_list[this.index] = [this.data_type, this.per_val, this.style_color["color"] ]
        sort_order[this.index] = []
        re_sort_order[this.index] = []
        this.updateDrawMessage(this.per_val, true);
        this.updateMappingChannel();

    },
    mounted(){
        this.type_selector = document.querySelector(".seletor"+this.index)
        this.scroll_unit = document.getElementById("canvas"+this.index)
        let node = this.scroll_unit, x=0, y=0;
        while(node.nodeName !== "MAIN"){
            x += node.offsetLeft, y += node.offsetTop;
            node = node.offsetParent;
        }
        this.box_para["rex"] = x, this.box_para["rey"] = y;
        this.box_para["rewi"] = this.scroll_unit.offsetWidth;
        node = document.getElementById("_"+this.index+"_0");
        x = 0;
        while(node.nodeName !== "MAIN"){
            x += node.offsetLeft;
            node = node.offsetParent;
        }
        this.box_para["canx"] = x+CODE_PADDING/2;
        this.synchronizeHighlight()
    },
    /// destroyed() at vue2.0
    unmounted(){
        for(let i=0; i<pers_index.length; i++){
            if(pers_index[i]===this.index){
                pers_index[i] = -1;
                break;
            }
        }

        if(this.base_sort === true) bus.emit("alignOrder", [-1, 0])

        delete data_lists[this.index]
        delete pers_list[this.index]
        delete sort_order[this.index]
        delete re_sort_order[this.index]
        /// update linechart
        if(interactive_list.length > 0){
            bus.emit("clickForLine", -1)
            bus.emit("analysisCode", [interactive_list[interactive_list.length-1], -1, {}])
        }
        
        /// in order to delete these bus correctly, I put these code in CodeCenter
        // bus.all.get("updateDataset").pop()
        // bus.all.get("updateVisualCode").pop()
        // bus.all.get("updateDataOrder").pop()
        // bus.all.get("changeRectOpacity").pop()
        // bus.all.get("changeLineOpacity").pop()
        // bus.all.get("clickForLine").pop()    
    }
}
</script>