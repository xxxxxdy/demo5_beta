<template>
    <div class="center">
        <div style="font-weight:bold; padding-left: 18px">visual code</div>
        <input type="button" class="clear" value="clear" @click="clearCanvas">
        <input type="button" class="name" value="name" @click="showName">
        <!--input type="button" class="export" value="export" @click="exportToCsv"-->
        <input type="button" class="add" style="font-size:18px" value="+" @click="addVisualCodeList">
        <div class="pers-bar">
            <div class="one-bar" v-for="item in visual_list" :key="item">
                <MyCodesList  ref="code_window" @delete="deleteVisualCodeList" :index="item" :show_name="show_name"/>
            </div>
        </div>
    </div>
</template>

<style scoped>
.center{
    width: 100%;
    height: 100%;
    border: solid #a1caf1 2px; 
    border-radius: 5px; 
    background: #a1caf1; 
    position: relative;
}
.pers-bar{
    position: relative;
    display: flex;
    width: 100%;
    height: 100%;
}

.one-bar{
    position: relative;
    width: 100%;
    height: 100%;
    margin-left: 2px;
    margin-right: 2px;
    transform: all 0.3s
}

.clear, .name, .export{
    margin-left: 12px;
    margin-bottom: 2px;
}

.add{
    position: absolute;
    right: 5px;
    top: 5px
}

</style>

<script>
import MyCodesList from './MyCodesList.vue';
import bus from '../util/eventBus';
import { interactive_list } from '../util/codeList';
import { color_for_highlight } from '../util/colorMapping';

export default{
    emits:['change'],
    components:{ MyCodesList },
    data(){
        return{
            show_name: false,
            visual_list: [0],
            latest_idx: 0
        }
    },

    methods:{
        showName(){
            if(this.show_name) this.show_name = false;
            else this.show_name = true;
        },

        exportToCsv(){

        },

        addVisualCodeList(){
            if(this.visual_list.length >= 3){
                alert('The visual codes list exceed its upper limit')
                return
            }
            this.visual_list.push(++this.latest_idx)
            this.$emit('change', this.visual_list.length)
        },

        deleteVisualCodeList(index){
            if(this.visual_list.length<=1){
                alert('This is the last visual code')
                return
            }
      
            for(let i=0; i<this.visual_list.length; i++){
                if(Number(index) === this.visual_list[i]){
                    this.visual_list.splice(i, 1)
                    bus.all.get("updateDataset").splice(i+2, 1)
                    bus.all.get("updateVisualCode").splice(i, 1)
                    bus.all.get("updateDataOrder").splice(i, 1)
                    bus.all.get("changeRectOpacity").splice(i, 1)
                    bus.all.get("changeLineOpacity").splice(i, 1)
                    bus.all.get("clickForLine").splice(i+1, 1)
                    bus.all.get("showSimilarityCode").splice(i, 1)
                    bus.all.get("calculateDistance").splice(i, 1)
                    bus.all.get("alignOrder").splice(i, 1)
                    bus.all.get("synchronizeScroll").splice(i, 1)
                    bus.all.get("filterCode").splice(i, 1)
                    break
                }
            }
            this.$emit('change', this.visual_list.length)
        },
        clearCanvas(){
            for(let i=0; i<this.visual_list.length; i++)
                this.$refs.code_window[i].clearHighlight()
            for(let key in color_for_highlight)
                delete color_for_highlight[key]
            interactive_list.splice(0, interactive_list.length)
            bus.emit("clickForLine", -1)
            bus.emit("analysisCode",[-1, -1, {}])
        }
        
    },

}
</script>