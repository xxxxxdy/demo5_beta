import { visualcode_object ,data_lists } from "./codeList"

export const sort_type = [
    "hills number",  /// 0, data_list[i].length
    "data width",  /// 1, newcode_list[i].end-newcode_list[i].start
    "start position", /// 2, newcode_list[i].start
    "max value", /// 3, newcode_list[i].max
    "data name" /// 4, newcode_list[i].name
]

export var sort_order = {}
export var re_sort_order = {}

export function getReSortOrder(idx){
    let tmp = new Array(sort_order[idx].length).fill(0);
    for(let i=0,len=sort_order[idx].length; i<len; i++){
        tmp[sort_order[idx][i]] = i;
    }
    re_sort_order[idx] = tmp;

    // console.log(sort_order, re_sort_order)
}

export function updateOrder(idx = 0, type = 2, sort_list = null){
    if(sort_list === null)
        sort_list = sort_type.map((name, index) =>{
            return { name, index, ban:false, reverse:false};
        })
    let tmp_order = []
    for(let i=0, len=visualcode_object[type].length; i<len; i++ ){
        tmp_order.push(i);
    }

    function cmp(a, b){
        for(let i=0; i<sort_list.length; i++){
            if(sort_list[i].ban) continue;
            let tmp; 
            switch(sort_list[i].index){
                case 0:
                    tmp = data_lists[idx][a].length - data_lists[idx][b].length;
                    break;
                case 1:
                    tmp = visualcode_object[type][a].getEndTime()-visualcode_object[type][a].getStartTime() 
                        - visualcode_object[type][b].getEndTime()+visualcode_object[type][b].getStartTime() ;
                    break;
                case 2:
                    tmp = visualcode_object[type][a].getStartTime() - visualcode_object[type][b].getStartTime();
                    break;
                case 3:
                    tmp = visualcode_object[type][a].max_value - visualcode_object[type][b].max_value;
                    break;
                case 4:
                    tmp = visualcode_object[type][a].name > visualcode_object[type][b].name;
                    break;
                default:
                    tmp = a-b; /// would not be executed forever
            }
            if(tmp === 0) continue;
            if(sort_list[i].reverse) return tmp;
            else return -tmp;
        }
        return a-b;
    }

    tmp_order.sort(cmp);
    sort_order[idx] = tmp_order;
    getReSortOrder(idx);
}